require 'spec_helper'

describe MoviesController do
  describe 'adding Director' do
    it 'should accept user input and map it to the director field in db' do
      fake_results = [mock('movie1'), mock('movie2')]
      ##Movie.should_receive(update_attributes).with('hardware').
        ##and_return(fake_results)
      post :update, {:controller => "movies"}
    end
  end
end